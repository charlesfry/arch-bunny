# Boot optimization A/B log

This is the concise chronological decision record for boot experiments. Raw
metrics and logs remain under
`~/VMs/dotfiles/test-results/boot-optimization/`.

## Entry rules

- Append an entry when an experiment starts, is promoted, is rejected, or is
  accepted; do not rewrite earlier entries.
- Limit each entry to one or two sentences.
- Include the experiment label, A and B VM names, active state, promotion state,
  result, primary overall timing, and results path when available.
- Use `active=yes` for the experiment currently being tested and `active=no`
  after a decision or replacement.
- Use one promotion state: `scratch`, `candidate`, `accepted`, or `rejected`.
- Write the overall timing as `overall[ENDPOINT]: A=SECONDS, B=SECONDS,
  delta=SECONDS`; use the median primary end-to-end metric and name its endpoint.
- Use `overall=pending` until a measured result exists.
- Keep raw command output, metrics, and detailed analysis out of this file.

## Entry format

```markdown
- YYYY-MM-DD HH:MM UTC — `LABEL`: A=`VM_NAME` (DESCRIPTION), B=`VM_NAME` (DESCRIPTION); active=yes, promotion=scratch. Result pending; overall=pending; results=`PATH`.
- YYYY-MM-DD HH:MM UTC — `LABEL`: A=`VM_NAME`, B=`VM_NAME`; active=no, promotion=accepted. Overall[desktop-ready]: A=9.420s, B=9.300s, delta=-0.120s; paired 95% CI excluded zero; results=`PATH`.
```

## Entries

<!-- Append new entries below this line. -->

- 2026-08-31 10:51 UTC — `null-ab`: A=`dotfiles-test-boot-baseline` (unchanged golden clone), B=`dotfiles-test-boot-candidate` (unchanged golden clone); active=yes, promotion=candidate. Result pending; overall=pending; results=`~/VMs/dotfiles/test-results/boot-optimization/comparisons/null-ab/`.
- 2026-08-31 11:09 UTC — `null-ab`: A=`dotfiles-test-boot-baseline` (unchanged golden clone), B=`dotfiles-test-boot-candidate` (unchanged golden clone); active=no, promotion=rejected. Manual LUKS timing produced a candidate penalty in kernel time while userspace remained equivalent; overall[desktop-ready]: A=20.839s, B=21.088s, delta=+0.249s; results=`~/VMs/dotfiles/test-results/boot-optimization/comparisons/null-ab/`.
- 2026-08-31 11:42 UTC — `null-ab-serial`: A=`dotfiles-test-boot-baseline` (unchanged golden clone with serial observer profile), B=`dotfiles-test-boot-candidate` (unchanged golden clone with serial observer profile); active=yes, promotion=candidate. Result pending; overall=pending; results=`~/VMs/dotfiles/test-results/boot-optimization/comparisons/null-ab-serial/`.
- 2026-08-31 11:58 UTC — `null-ab-serial`: A=`dotfiles-test-boot-baseline`, B=`dotfiles-test-boot-candidate`; active=no, promotion=accepted. Automated null floor established with desktop-ready paired 95% CI including zero; overall[desktop-ready]: A=18.620s, B=18.713s, delta=+0.093s; results=`~/VMs/dotfiles/test-results/boot-optimization/comparisons/null-ab-serial/`.
- 2026-08-31 12:32 UTC — `autodetect-after-udev`: A=`dotfiles-test-boot-baseline` (golden hooks), B=`dotfiles-test-boot-scratch` (autodetect immediately after udev); active=yes, promotion=scratch. Result pending; overall=pending; results=`~/VMs/dotfiles/test-results/boot-optimization/boot-scratch/boot/autodetect-after-udev/`.
- 2026-08-31 12:35 UTC — `autodetect-after-udev`: A=`dotfiles-test-boot-baseline` (golden hooks), B=`dotfiles-test-boot-scratch` (autodetect immediately after udev); active=no, promotion=rejected. UKI shrank from 41,447,424 to 39,475,712 bytes but three scratch boots regressed; overall[desktop-ready]: A=18.620s, B=21.634s, delta=+3.014s; results=`~/VMs/dotfiles/test-results/boot-optimization/boot-scratch/boot/autodetect-after-udev/`.
- 2026-08-31 12:40 UTC — `initramfs-lz4`: A=`dotfiles-test-boot-baseline` (default zstd), B=`dotfiles-test-boot-scratch` (LZ4); active=yes, promotion=scratch. Result pending; overall=pending; results=`~/VMs/dotfiles/test-results/boot-optimization/boot-scratch/boot/initramfs-lz4/`.
- 2026-08-31 12:43 UTC — `initramfs-lz4`: A=`dotfiles-test-boot-baseline` (default zstd), B=`dotfiles-test-boot-scratch` (LZ4); active=no, promotion=rejected. UKI grew from 41,447,424 to 49,392,640 bytes and three boots regressed; overall[desktop-ready]: A=18.620s, B=21.430s, delta=+2.810s; results=`~/VMs/dotfiles/test-results/boot-optimization/boot-scratch/boot/initramfs-lz4/`.
- 2026-08-31 13:19 UTC — `initramfs-zstd-1`: A=`dotfiles-test-boot-baseline` (default zstd), B=`dotfiles-test-boot-scratch` (zstd level 1); active=yes, promotion=scratch. Result pending; overall=pending; results=`~/VMs/dotfiles/test-results/boot-optimization/boot-scratch/boot/initramfs-zstd-1/`.
- 2026-08-31 13:22 UTC — `initramfs-zstd-1`: A=`dotfiles-test-boot-baseline` (default zstd), B=`dotfiles-test-boot-scratch` (zstd level 1); active=no, promotion=rejected. UKI grew from 41,447,424 to 43,329,536 bytes and three boots regressed; overall[desktop-ready]: A=18.620s, B=21.023s, delta=+2.403s; results=`~/VMs/dotfiles/test-results/boot-optimization/boot-scratch/boot/initramfs-zstd-1/`.
- 2026-08-31 13:26 UTC — `initramfs-no-plymouth-hook`: A=`dotfiles-test-boot-baseline` (Plymouth hook present, runtime disabled), B=`dotfiles-test-boot-scratch` (Plymouth hook removed); active=yes, promotion=scratch. Result pending; overall=pending; results=`~/VMs/dotfiles/test-results/boot-optimization/boot-scratch/boot/initramfs-no-plymouth-hook/`.
- 2026-08-31 13:30 UTC — `initramfs-no-plymouth-hook`: A=`dotfiles-test-boot-baseline` (Plymouth hook present, runtime disabled), B=`dotfiles-test-boot-scratch` (Plymouth hook removed); active=no, promotion=rejected. UKI shrank from 41,447,424 to 38,856,192 bytes, but the first boot never reached SSH or acquired a lease after serial submission; overall=pending; results=`~/VMs/dotfiles/test-results/boot-optimization/boot-scratch/apply/initramfs-no-plymouth-hook/`.
- 2026-08-31 13:31 UTC — `initramfs-zstd-19`: A=`dotfiles-test-boot-baseline` (default zstd), B=`dotfiles-test-boot-scratch` (zstd level 19); active=yes, promotion=scratch. Result pending; overall=pending; results=`~/VMs/dotfiles/test-results/boot-optimization/boot-scratch/boot/initramfs-zstd-19/`.
- 2026-08-31 13:34 UTC — `initramfs-zstd-19`: A=`dotfiles-test-boot-baseline` (default zstd), B=`dotfiles-test-boot-scratch` (zstd level 19); active=no, promotion=rejected. UKI shrank from 41,447,424 to 38,382,080 bytes but three boots regressed; overall[desktop-ready]: A=18.620s, B=21.792s, delta=+3.172s; results=`~/VMs/dotfiles/test-results/boot-optimization/boot-scratch/boot/initramfs-zstd-19/`.
- 2026-08-31 14:18 UTC — `autodetect-before-keyboard`: A=`dotfiles-test-boot-baseline` (autodetect after keyboard), B=`dotfiles-test-boot-scratch` (autodetect before keyboard); active=yes, promotion=scratch. Result pending; overall=pending; results=`~/VMs/dotfiles/test-results/boot-optimization/boot-scratch/boot/autodetect-before-keyboard/`.
- 2026-08-31 14:21 UTC — `autodetect-before-keyboard`: A=`dotfiles-test-boot-baseline` (autodetect after keyboard), B=`dotfiles-test-boot-scratch` (autodetect before keyboard); active=no, promotion=rejected. UKI shrank from 41,447,424 to 39,475,712 bytes but three boots regressed; overall[desktop-ready]: A=18.620s, B=20.623s, delta=+2.003s; results=`~/VMs/dotfiles/test-results/boot-optimization/boot-scratch/boot/autodetect-before-keyboard/`.
- 2026-08-31 14:27 UTC — `disable-power-profiles`: A=`dotfiles-test-boot-baseline` (power-profiles-daemon enabled), B=`dotfiles-test-boot-scratch` (power-profiles-daemon disabled); active=yes, promotion=scratch. Result pending; overall=pending; results=`~/VMs/dotfiles/test-results/boot-optimization/boot-scratch/boot/disable-power-profiles/`.
- 2026-08-31 14:34 UTC — `disable-power-profiles`: A=`dotfiles-test-boot-baseline` (power-profiles-daemon enabled), B=`dotfiles-test-boot-scratch` (power-profiles-daemon disabled); active=no, promotion=rejected. System userspace improved but desktop readiness did not; overall[desktop-ready]: A=20.148s, B=20.303s, delta=+0.155s; results=`~/VMs/dotfiles/test-results/boot-optimization/comparisons/disable-power-profiles-paired/`.
- 2026-08-31 15:04 UTC — `userdb-files-only`: A=`dotfiles-test-boot-baseline` (files plus systemd userdb NSS), B=`dotfiles-test-boot-scratch` (local files NSS only); active=yes, promotion=scratch. Result pending; overall=pending; results=`~/VMs/dotfiles/test-results/boot-optimization/comparisons/userdb-files-only-paired/`.
- 2026-08-31 15:10 UTC — `userdb-files-only`: A=`dotfiles-test-boot-baseline` (files plus systemd userdb NSS), B=`dotfiles-test-boot-candidate` (fresh serial clone with local files NSS only); active=yes, promotion=candidate. Three-pair scratch result improved desktop readiness; overall[desktop-ready]: A=20.363s, B=20.020s, delta=-0.343s; results=`~/VMs/dotfiles/test-results/boot-optimization/comparisons/userdb-files-only-paired/`.
- 2026-08-31 15:28 UTC — `userdb-files-only`: A=`dotfiles-test-boot-baseline` (files plus systemd userdb NSS), B=`dotfiles-test-boot-candidate` (local files NSS only); active=no, promotion=rejected. Fifteen pairs improved timing but the 0.356s gain does not justify dropping nss-systemd account semantics; overall[desktop-ready]: A=20.277s, B=19.920s, delta=-0.357s; results=`~/VMs/dotfiles/test-results/boot-optimization/comparisons/userdb-files-only-acceptance/`.
